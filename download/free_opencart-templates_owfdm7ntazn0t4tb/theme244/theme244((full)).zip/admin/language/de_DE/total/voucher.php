<?php
// Heading
$_['heading_title']    = 'Geschenkgutschein';

// Text
$_['text_total']       = 'Auftragssumme';
$_['text_success']     = 'Erfolgreich: Geschenkgutschein erfolgreich geändert!';

// Entry
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Reihenfolge:';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um Geschenkgutscheine zu bearbeiten!';
?>
