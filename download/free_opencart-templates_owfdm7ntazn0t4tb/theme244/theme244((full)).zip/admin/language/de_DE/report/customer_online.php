<?php
// Heading
$_['heading_title']     = 'Kunden Online Bericht';

// Text 
$_['text_guest']        = 'Gast';
 
// Column
$_['column_ip']         = 'IP-Adresse';
$_['column_customer']   = 'Kunde';
$_['column_url']        = 'Letzte besuchte Seite';
$_['column_referer']    = 'Herkunft';
$_['column_date_added'] = 'Letzter Klick';
$_['column_action']     = 'Aktion';
?>