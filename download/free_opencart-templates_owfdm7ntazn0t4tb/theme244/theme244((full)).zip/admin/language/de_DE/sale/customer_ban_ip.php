<?php
$_['column_action']    = 'Aktion';
$_['column_customer']  = 'Kunden';
$_['column_ip']        = 'IP-Adresse';
$_['entry_ip']         = 'IP-Adresse:';
$_['error_ip']         = 'IP-Adresse muss zwischen 1 und 15 Zeichen lang sein!';
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um das Modul Kunden Negativliste zu ändern!';
$_['heading_title']    = 'Kunden IP-Adressen Negativliste';
$_['text_success']     = 'Erfolgreich: Sie haben das Modul Kunden Negativliste geändert!';
?>

