<?php
$_['error_filetype']   = 'Warnung: Ungültiger Dateityp!';
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um den Erweiterungsmanager zu ändern!';
$_['error_upload']     = 'Warnung: Upload benötigt!';
$_['heading_title']    = 'Erweiterungsmanager';
$_['text_success']     = 'Erfolgreich: Die Erweiterung wurde installiert!';
?>

